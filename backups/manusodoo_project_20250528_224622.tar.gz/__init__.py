# FastAPI Middleware para simular Odoo
# Este archivo inicializa el paquete app
