import heroImage from '../../assets/images/hero.jpg';

const HeroSection = () => {
  return (
    <section className="relative h-[500px] md:h-[600px] overflow-hidden">
      {/* Hero Image */}
      <div className="absolute inset-0">
        <img 
          src={heroImage} 
          alt="Electrodomésticos y soluciones para el hogar" 
          className="w-full h-full object-cover"
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30"></div>
      </div>
      
      {/* Content */}
      <div className="relative container mx-auto px-4 h-full flex flex-col justify-center">
        <div className="max-w-lg text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Electrodomésticos y soluciones para tu hogar
          </h1>
          <p className="text-lg md:text-xl mb-8">
            En El Pelotazo Electrohogar encontrarás electrodomésticos y soluciones para tu hogar con calidad y confianza.
          </p>
          <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-full transition-colors">
            Ver productos
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
