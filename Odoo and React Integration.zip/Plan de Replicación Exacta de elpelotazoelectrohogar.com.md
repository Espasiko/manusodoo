# Plan de Replicación Exacta de elpelotazoelectrohogar.com

## 1. Estructura de Componentes

### Componentes Principales
1. **Header**
   - Logo principal
   - Menú de navegación (Inicio, Nosotros, Productos, Contacto)
   - Buscador con icono
   - Diseño responsive con menú hamburguesa en móvil

2. **Hero Section**
   - Banner principal con imagen de fondo (shutterstock_2473408983.jpg)
   - Texto superpuesto y llamada a acción

3. **Categorías Destacadas**
   - Grid de categorías con imágenes y títulos
   - Efectos hover

4. **Productos Destacados**
   - Carrusel/grid de productos
   - Imágenes, títulos, precios y botones de acción

5. **Banner Promocional**
   - Sección con fondo de color/imagen
   - Texto promocional y llamada a acción

6. **Servicios/Ventajas**
   - Iconos con texto descriptivo
   - Disposición en grid

7. **Footer**
   - Logo
   - Enlaces de navegación
   - Información de contacto
   - Redes sociales
   - Copyright

## 2. Recursos Visuales

### Imágenes a Replicar
1. **Logo**: `/home/ubuntu/pelotazo_site/logo.png`
2. **Hero Banner**: `/home/ubuntu/pelotazo_site/hero.jpg`
3. **Imágenes de Categorías**: Descargar de la web original
4. **Imágenes de Productos**: Descargar de la web original
5. **Iconos**: Utilizar biblioteca de iconos similar a la original (Font Awesome o equivalente)

### Fuentes y Tipografía
- Identificar y utilizar las mismas fuentes o equivalentes cercanos
- Mantener tamaños, pesos y estilos exactos

### Paleta de Colores
- Extraer colores exactos del sitio original mediante inspección
- Definir variables CSS para mantener consistencia

## 3. Estrategia de Implementación

### Estructura de Archivos
```
src/
├── assets/
│   ├── images/
│   │   ├── logo.png
│   │   ├── hero.jpg
│   │   ├── categories/
│   │   ├── products/
│   │   └── icons/
│   └── fonts/
├── components/
│   ├── layout/
│   │   ├── Header.tsx
│   │   └── Footer.tsx
│   ├── sections/
│   │   ├── HeroSection.tsx
│   │   ├── CategoriesSection.tsx
│   │   ├── ProductsSection.tsx
│   │   ├── PromoBanner.tsx
│   │   └── ServicesSection.tsx
│   └── ui/
│       ├── Button.tsx
│       ├── ProductCard.tsx
│       ├── CategoryCard.tsx
│       └── SearchBar.tsx
├── styles/
│   ├── globals.css
│   └── variables.css
└── pages/
    └── Home.tsx
```

### Enfoque CSS
1. **Tailwind CSS**:
   - Utilizar Tailwind para la estructura base
   - Configurar theme en `tailwind.config.js` para coincidir con la paleta de colores original

2. **CSS Personalizado**:
   - Crear estilos específicos para replicar efectos exactos
   - Utilizar clases específicas para mantener la fidelidad visual

3. **Responsive Design**:
   - Replicar el comportamiento responsive exacto del sitio original
   - Puntos de quiebre idénticos para móvil, tablet y escritorio

## 4. Detalles de Implementación por Componente

### Header
- Posición fija en scroll
- Menú desplegable en móvil
- Transiciones suaves en hover
- Indicador de página activa

### Hero Section
- Imagen de fondo a pantalla completa
- Overlay con gradiente para mejorar legibilidad del texto
- Botón de llamada a acción con efecto hover

### Categorías Destacadas
- Grid responsive (4 columnas en desktop, 2 en tablet, 1 en móvil)
- Efecto hover con zoom suave y cambio de opacidad
- Títulos centrados sobre las imágenes

### Productos Destacados
- Carrusel con navegación por flechas
- Tarjetas de producto con imagen, título, precio y botón
- Efecto hover con elevación (shadow)

### Banner Promocional
- Fondo con imagen o color de acento
- Texto centrado o alineado según diseño original
- Botón de llamada a acción destacado

### Servicios/Ventajas
- Iconos con tamaño y color idénticos al original
- Disposición en grid responsive
- Espaciado y alineación precisos

### Footer
- Estructura multi-columna en desktop, apilada en móvil
- Enlaces con efectos hover sutiles
- Iconos de redes sociales con colores originales
- Línea separadora y copyright en la parte inferior

## 5. Interactividad y Comportamiento

### Menú de Navegación
- Implementar comportamiento exacto del menú desplegable
- Transiciones y animaciones idénticas

### Carruseles
- Replicar comportamiento de autoplay si existe
- Navegación por flechas y/o puntos
- Transiciones suaves entre slides

### Efectos Hover
- Replicar todos los efectos hover en enlaces, botones y tarjetas
- Mantener tiempos de transición idénticos

### Formulario de Búsqueda
- Comportamiento de expansión/contracción si aplica
- Estilo de campo de búsqueda idéntico

## 6. Optimización y Rendimiento

### Imágenes
- Optimizar todas las imágenes manteniendo calidad visual
- Implementar carga lazy para mejorar rendimiento

### Fuentes
- Precargar fuentes críticas
- Utilizar formatos modernos (woff2)

### CSS
- Minimizar CSS final
- Eliminar estilos no utilizados

## 7. Pruebas y Validación

### Comparación Visual
- Comparar pixel por pixel con capturas de pantalla del original
- Verificar alineación, espaciado y proporciones

### Responsive Testing
- Probar en múltiples tamaños de pantalla
- Verificar puntos de quiebre exactos

### Compatibilidad de Navegadores
- Probar en Chrome, Firefox, Safari y Edge
- Asegurar consistencia visual en todos los navegadores

## 8. Entrega Final

### Despliegue
- Configurar build optimizado
- Desplegar en servidor estático

### Documentación
- Documentar estructura de componentes
- Incluir capturas de pantalla comparativas
- Proporcionar instrucciones de mantenimiento
