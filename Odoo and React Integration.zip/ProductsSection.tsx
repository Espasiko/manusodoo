const ProductsSection = () => {
  // Datos de ejemplo para los productos
  const products = [
    {
      id: 1,
      title: "Lavadora Automática",
      price: 399.99,
      image: "https://via.placeholder.com/300x300/e2e8f0/1e40af?text=Lavadora",
    },
    {
      id: 2,
      title: "Refrigerador No Frost",
      price: 599.99,
      image: "https://via.placeholder.com/300x300/e2e8f0/1e40af?text=Refrigerador",
    },
    {
      id: 3,
      title: "Microondas Digital",
      price: 129.99,
      image: "https://via.placeholder.com/300x300/e2e8f0/1e40af?text=Microondas",
    },
    {
      id: 4,
      title: "Televisor Smart 43\"",
      price: 349.99,
      image: "https://via.placeholder.com/300x300/e2e8f0/1e40af?text=Televisor",
    }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Productos Destacados</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div key={product.id} className="group bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-xl">
              {/* Imagen del producto */}
              <div className="h-64 overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              
              {/* Información del producto */}
              <div className="p-4">
                <h3 className="text-lg font-medium mb-2">{product.title}</h3>
                <p className="text-blue-800 text-xl font-bold mb-4">€{product.price.toFixed(2)}</p>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded transition-colors">
                  Ver detalles
                </button>
              </div>
              
              {/* Enlace completo */}
              <a href={`/producto/${product.id}`} className="absolute inset-0" aria-label={`Ver detalles de ${product.title}`}></a>
            </div>
          ))}
        </div>
        
        {/* Botón Ver todos */}
        <div className="text-center mt-10">
          <a 
            href="/productos" 
            className="inline-block border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-medium py-3 px-8 rounded-full transition-colors"
          >
            Ver todos los productos
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;
