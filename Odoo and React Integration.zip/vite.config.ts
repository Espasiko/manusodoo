import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    host: "0.0.0.0",
    strictPort: false,
    open: false,
    hmr: {
      overlay: false,
    },
    proxy: {
      "/api": {
        target: "http://localhost:8069",
        changeOrigin: true,
        secure: false,
      },
    },
    allowedHosts: [
      "localhost",
      "3000-ishxvgs1vcbjdsxvwnkcc-72b27711.manusvm.computer",
      "3001-ishxvgs1vcbjdsxvwnkcc-72b27711.manusvm.computer"
    ]
  },
});
