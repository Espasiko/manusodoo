import OdooClient from './odooClient';

class OdooService {
  private client: OdooClient;
  private isAuthenticated: boolean = false;

  constructor() {
    this.client = new OdooClient();
  }

  async login(username: string, password: string): Promise<boolean> {
    try {
      const success = await this.client.login();
      this.isAuthenticated = success;
      return success;
    } catch (error) {
      console.error('Error en el servicio de login:', error);
      return false;
    }
  }

  logout(): void {
    this.isAuthenticated = false;
  }

  async getProducts(limit: number = 10): Promise<any[]> {
    if (!this.isAuthenticated) {
      await this.client.login();
    }

    return this.client.searchRead(
      'product.template',
      [['sale_ok', '=', true]],
      ['id', 'name', 'list_price', 'default_code', 'qty_available', 'image_1920'],
      limit
    );
  }

  async getInventory(limit: number = 10): Promise<any[]> {
    if (!this.isAuthenticated) {
      await this.client.login();
    }

    return this.client.searchRead(
      'stock.quant',
      [],
      ['id', 'product_id', 'location_id', 'quantity', 'reserved_quantity'],
      limit
    );
  }

  async getSales(limit: number = 10): Promise<any[]> {
    if (!this.isAuthenticated) {
      await this.client.login();
    }

    return this.client.searchRead(
      'sale.order',
      [],
      ['id', 'name', 'partner_id', 'date_order', 'amount_total', 'state'],
      limit
    );
  }

  async getCustomers(limit: number = 10): Promise<any[]> {
    if (!this.isAuthenticated) {
      await this.client.login();
    }

    return this.client.searchRead(
      'res.partner',
      [['customer_rank', '>', 0]],
      ['id', 'name', 'email', 'phone', 'city', 'country_id'],
      limit
    );
  }
}

export const odooService = new OdooService();
