# Documentación del Dashboard para Tienda de Electrodomésticos

## Descripción General

Este proyecto implementa un dashboard para una tienda de electrodomésticos utilizando:

- **Frontend**: React con Refine y Ant Design
- **Backend**: API FastAPI que simula los endpoints de Odoo
- **Integración futura**: Preparado para conectar con Odoo real

El sistema está diseñado para funcionar tanto con el middleware FastAPI (para desarrollo y pruebas) como con una instalación real de Odoo (en producción).

## Estructura del Proyecto

```
odoo_erp_project/
├── dashboard/
│   └── frontend/
│       └── odoo-dashboard/
│           ├── src/
│           │   ├── api/
│           │   │   ├── odooClient.ts    # Cliente para comunicación con backend
│           │   │   └── odooService.ts   # Servicios para operaciones de negocio
│           │   ├── components/
│           │   ├── contexts/
│           │   ├── pages/
│           │   └── App.tsx
│           ├── .env                     # Variables de entorno
│           ├── package.json
│           └── vite.config.ts
└── middleware/
    ├── app/
    │   ├── __init__.py
    │   └── main.py                      # API FastAPI que simula Odoo
    ├── requirements.txt
    └── README.md
```

## Configuración del Entorno Local

### Requisitos Previos

- Node.js v18+ o v20+ (LTS recomendado)
- Python 3.8+
- Opcional: Odoo 16+ (si se desea conectar con Odoo real)

### Paso 1: Configurar el Middleware FastAPI

1. Navegar al directorio del middleware:
   ```bash
   cd odoo_erp_project/middleware
   ```

2. Crear un entorno virtual (opcional pero recomendado):
   ```bash
   python -m venv venv
   source venv/bin/activate  # En Windows: venv\Scripts\activate
   ```

3. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```

4. Iniciar el servidor FastAPI:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```

5. Verificar que el servidor está funcionando accediendo a:
   ```
   http://localhost:8000/docs
   ```

### Paso 2: Configurar el Frontend

1. Navegar al directorio del frontend:
   ```bash
   cd odoo_erp_project/dashboard/frontend/odoo-dashboard
   ```

2. Instalar dependencias:
   ```bash
   npm install
   ```

3. Configurar variables de entorno:
   - Crear o editar el archivo `.env` con el siguiente contenido:
   ```
   VITE_ODOO_URL=http://localhost:8000
   VITE_ODOO_DB=odoo_electrodomesticos
   VITE_ODOO_USERNAME=admin
   VITE_ODOO_PASSWORD=admin_password_secure
   ```

4. Iniciar el servidor de desarrollo:
   ```bash
   npm run dev
   ```

5. Acceder al dashboard en:
   ```
   http://localhost:5173
   ```

## Uso con Odoo Real (WSL)

Si deseas conectar el dashboard con una instalación real de Odoo en WSL:

1. Instalar Odoo en WSL siguiendo la documentación oficial
2. Crear una base de datos llamada `odoo_electrodomesticos`
3. Modificar el archivo `.env` del frontend:
   ```
   VITE_ODOO_URL=http://localhost:8069  # Puerto estándar de Odoo
   VITE_ODOO_DB=odoo_electrodomesticos
   VITE_ODOO_USERNAME=admin
   VITE_ODOO_PASSWORD=tu_contraseña_de_odoo
   ```
4. Modificar el archivo `odooClient.ts` para usar la versión original que se comunica con Odoo mediante JSON-RPC

## Autenticación

### Con el Middleware FastAPI

- Usuario: `admin`
- Contraseña: `admin_password_secure`
- Método: OAuth2 con token JWT

### Con Odoo Real

- Usuario: El configurado en tu instalación de Odoo
- Contraseña: La configurada en tu instalación de Odoo
- Método: Autenticación de sesión de Odoo

## Solución de Problemas Comunes

### Problemas de CORS

Si encuentras errores de CORS:

1. Verifica que el middleware tenga configurado correctamente los orígenes permitidos
2. Asegúrate de que las URLs en el frontend incluyan el protocolo (http://)

### Errores de Autenticación

1. Verifica las credenciales en el archivo `.env`
2. Comprueba que el servidor FastAPI o Odoo esté ejecutándose
3. Revisa los logs del servidor para identificar posibles problemas

### Problemas de Conexión

1. Verifica que los puertos sean accesibles (8000 para FastAPI, 8069 para Odoo)
2. Si usas WSL, asegúrate de que los puertos estén correctamente redirigidos

## Desarrollo y Extensión

### Añadir Nuevos Endpoints al Middleware

1. Edita el archivo `middleware/app/main.py`
2. Añade nuevos endpoints siguiendo el patrón existente
3. Actualiza el cliente en `dashboard/frontend/odoo-dashboard/src/api/odooClient.ts`

### Añadir Nuevas Páginas al Dashboard

1. Crea un nuevo archivo en `dashboard/frontend/odoo-dashboard/src/pages/`
2. Añade la ruta en `App.tsx`
3. Actualiza el menú en `components/sider.tsx`

## Notas Importantes

- El middleware FastAPI es solo para desarrollo y pruebas, no para producción
- Para un entorno de producción, se recomienda conectar directamente con Odoo
- Las credenciales en este documento son solo para desarrollo, usa credenciales seguras en producción
