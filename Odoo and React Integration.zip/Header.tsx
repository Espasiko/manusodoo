import { useState } from 'react';
import logo from '../../assets/images/logo.png';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 bg-white shadow-md z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <div className="w-48 md:w-64">
          <a href="/">
            <img src={logo} alt="El Pelotazo Electrohogar" className="w-full h-auto" />
          </a>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="/" className="text-blue-800 font-medium border-b-2 border-blue-800">Inicio</a>
          <a href="/nosotros" className="text-gray-700 hover:text-blue-800 hover:border-b-2 hover:border-blue-800 transition-all">Nosotros</a>
          <a href="/productos" className="text-gray-700 hover:text-blue-800 hover:border-b-2 hover:border-blue-800 transition-all">Productos</a>
          <a href="/contacto" className="text-gray-700 hover:text-blue-800 hover:border-b-2 hover:border-blue-800 transition-all">Contacto</a>
          
          {/* Search Icon */}
          <button className="text-gray-700 hover:text-blue-800" aria-label="Buscar">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700 focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Menú"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <nav className="md:hidden bg-white border-t border-gray-200 px-4 py-3">
          <div className="flex flex-col space-y-3">
            <a href="/" className="text-blue-800 font-medium py-2">Inicio</a>
            <a href="/nosotros" className="text-gray-700 hover:text-blue-800 py-2">Nosotros</a>
            <a href="/productos" className="text-gray-700 hover:text-blue-800 py-2">Productos</a>
            <a href="/contacto" className="text-gray-700 hover:text-blue-800 py-2">Contacto</a>
            
            {/* Search Bar for Mobile */}
            <div className="relative mt-2">
              <input 
                type="text" 
                placeholder="Buscar..." 
                className="w-full py-2 px-4 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-800 focus:border-transparent"
              />
              <button className="absolute right-3 top-2.5 text-gray-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Header;
