const PromoBanner = () => {
  return (
    <section className="py-16 bg-blue-800 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Ofertas Especiales</h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Descubre nuestras promociones exclusivas en electrodomésticos de las mejores marcas. ¡No te pierdas estas oportunidades!
        </p>
        <button className="bg-white text-blue-800 hover:bg-gray-100 font-medium py-3 px-8 rounded-full transition-colors">
          Ver ofertas
        </button>
      </div>
    </section>
  );
};

export default PromoBanner;
