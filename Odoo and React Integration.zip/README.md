# Documentación del Middleware FastAPI para Odoo

Este middleware simula la API de Odoo para permitir el desarrollo y pruebas del dashboard frontend sin necesidad de tener Odoo instalado localmente.

## Instalación

1. Instala las dependencias:
```bash
cd /home/ubuntu/odoo_erp_project/middleware
pip install -r requirements.txt
```

2. Inicia el servidor:
```bash
cd /home/ubuntu/odoo_erp_project/middleware
uvicorn app.main:app --host 0.0.0.0 --port 8069 --reload
```

## Endpoints disponibles

### Autenticación

- **POST /token**
  - Simula la autenticación de Odoo
  - Cuerpo de la petición: `username` y `password` (form-data)
  - Respuesta: Token JWT para autenticación
  - Credenciales de prueba: `admin` / `admin_password_secure`

- **GET /api/v1/auth/session**
  - Obtiene información de la sesión actual
  - Requiere autenticación: Sí (Bearer token)
  - Respuesta: Información de la sesión (uid, username, name, session_id, db)

### Productos

- **GET /api/v1/products**
  - Obtiene la lista de productos
  - Requiere autenticación: Sí
  - Respuesta: Array de productos con sus detalles

- **GET /api/v1/products/{product_id}**
  - Obtiene detalles de un producto específico
  - Requiere autenticación: Sí
  - Respuesta: Detalles del producto

### Inventario

- **GET /api/v1/inventory**
  - Obtiene la lista de elementos de inventario
  - Requiere autenticación: Sí
  - Respuesta: Array de elementos de inventario

### Ventas

- **GET /api/v1/sales**
  - Obtiene la lista de ventas
  - Requiere autenticación: Sí
  - Respuesta: Array de ventas con sus detalles

### Clientes

- **GET /api/v1/customers**
  - Obtiene la lista de clientes
  - Requiere autenticación: Sí
  - Respuesta: Array de clientes con sus detalles

### Dashboard

- **GET /api/v1/dashboard/stats**
  - Obtiene estadísticas para el dashboard
  - Requiere autenticación: Sí
  - Respuesta: Estadísticas generales (productos, stock bajo, ventas, clientes activos, categorías)

## Documentación interactiva

La API incluye documentación interactiva generada automáticamente:
- Swagger UI: http://localhost:8069/docs
- ReDoc: http://localhost:8069/redoc

## Integración con el frontend

Para conectar el frontend con este middleware:

1. Actualiza el archivo `.env` en el directorio del frontend:
```
VITE_ODOO_URL=http://localhost:8069
VITE_ODOO_DB=odoo_electrodomesticos
VITE_ODOO_USERNAME=admin
VITE_ODOO_PASSWORD=admin_password_secure
```

2. Asegúrate de que el cliente Odoo en el frontend esté configurado para usar estos endpoints.

## Migración a Odoo real

Cuando estés listo para migrar a Odoo real:

1. Instala Odoo en tu entorno WSL
2. Configura la base de datos `odoo_electrodomesticos`
3. Actualiza el archivo `.env` con la URL y credenciales de tu instalación de Odoo
4. El frontend debería funcionar sin cambios adicionales, ya que el middleware implementa los mismos endpoints que Odoo

## Notas adicionales

- Este middleware simula los endpoints básicos de Odoo, pero no implementa toda la funcionalidad
- Los datos son estáticos y se reinician al reiniciar el servidor
- Para añadir más datos de prueba, modifica los arrays en `app/main.py`
