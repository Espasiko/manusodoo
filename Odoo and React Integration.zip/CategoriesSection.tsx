const CategoriesSection = () => {
  // Datos de ejemplo para las categorías
  const categories = [
    {
      id: 1,
      title: "Electrodomésticos",
      image: "https://via.placeholder.com/300x200/e2e8f0/1e40af?text=Electrodomésticos",
    },
    {
      id: 2,
      title: "Cocina",
      image: "https://via.placeholder.com/300x200/e2e8f0/1e40af?text=Cocina",
    },
    {
      id: 3,
      title: "Lavado",
      image: "https://via.placeholder.com/300x200/e2e8f0/1e40af?text=Lavado",
    },
    {
      id: 4,
      title: "Climatización",
      image: "https://via.placeholder.com/300x200/e2e8f0/1e40af?text=Climatización",
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Categorías Destacadas</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <div key={category.id} className="group relative overflow-hidden rounded-lg shadow-md transition-all duration-300 hover:shadow-xl">
              {/* Imagen de categoría */}
              <div className="h-48 overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              {/* Overlay con título */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                <h3 className="text-white text-xl font-medium">{category.title}</h3>
              </div>
              
              {/* Enlace completo */}
              <a href={`/categoria/${category.id}`} className="absolute inset-0" aria-label={`Ver categoría ${category.title}`}></a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;
